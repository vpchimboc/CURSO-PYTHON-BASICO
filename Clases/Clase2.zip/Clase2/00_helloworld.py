
### CURSO PYTHON BASICO ###
#### Hola Mundo ###

# Nuestro hola mundo en Python
print("Hola Python")
print('Hola Python')

# Esto es un comentario
" Esto es un comentario" 

"""
Este es un
comentario
en varias líneas
"""

'''
Este también es un
comentario
en varias líneas
'''

# Cómo consultar el tipo de dato
print(type("Soy un dato str")) # Tipo 'str'
print(type(5)) # Tipo 'int'
print(type(1.5)) # Tipo 'float'
print(type(3 + 1j)) # Tipo 'complex'
print(type(True)) # Tipo 'bool'
print(type(print("Mi cadena de texto"))) # Tipo 'NoneType'